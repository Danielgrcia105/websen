Salario_Inicial = 1500  

Incremento_Anual = 0.10  

Años = 6  

 

for Año in range(1, Años + 1):

    Salario_Anual = Salario_Inicial + (Salario_Inicial * Incremento_Anual)

    print("Año", Año, ": $", Salario_Anual)

    Salario_Inicial = Salario_Anual  

 

print("Salario al cabo de 6 años: $", Salario_Anual)