# Solicitar al usuario los dos números reales
base = float(input("Ingrese el primer número: "))
exponente = float(input("Ingrese el segundo número: "))

# Calcular la potencia
resultado = base ** exponente

# Imprimir el resultado
print(f"{base} elevado a {exponente} es igual a: {resultado}")
