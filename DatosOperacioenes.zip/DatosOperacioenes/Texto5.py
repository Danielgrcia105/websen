frase = input("por favo, introduce una frase: ")
frase_invertida = frase [::-1]
print ("La frase invertida es: ", frase_invertida)