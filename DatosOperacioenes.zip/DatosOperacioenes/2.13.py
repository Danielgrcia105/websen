# Solicitar al usuario un número
numero = float(input("Ingrese un número: "))

# Calcular la raíz cúbica
raiz_cubica = numero ** (1/3)

# Imprimir el resultado
print(f"La raíz cúbica de {numero} es: {raiz_cubica}")
