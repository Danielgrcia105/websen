#PIde al usuario que ingrese los productos de su cesta de la compra
producto = input("Por favor, introduce los productos de tu cesta de la compra, separados por comas: ")
#Separa los productos por comas
lista_productos = producto.split(",")
#Muestra cada producto en una linea distinta for producto in lista_productos:
print (producto.strip())