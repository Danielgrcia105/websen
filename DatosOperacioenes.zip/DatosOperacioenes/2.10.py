import math

# Calcula el coseno de PI/4 radianes
angle = math.pi/4
cosine = math.cos(angle)

# Imprime el resultado
print(f"El coseno de {angle} radianes es: {cosine}")
