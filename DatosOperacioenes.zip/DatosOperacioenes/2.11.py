import math

# Convierte el ángulo de grados a radianes
angle_degrees = 45
angle_radians = math.radians(angle_degrees)

# Calcula el coseno del ángulo en radianes
cosine = math.cos(angle_radians)

# Imprime el resultado
print(f"El coseno de {angle_degrees} grados es: {cosine}")
