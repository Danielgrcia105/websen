#Pide al usuario que ingrese el precio del producto precio
precio = input("Por favor, introduce el precio del producto en euros con dos decimales: ")
#Convierte el precio a float precio_float = float(precio)
#Separa los euros y los centimos
euros = int("precio_float")
centimos = int(round("precio_float - euros") * 100)
#Muestra el resultado
print ("El precio del producto es de [] euros y [] centimos .".format(euros, centimos))