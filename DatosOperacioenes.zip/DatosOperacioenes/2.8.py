import math

num = float(input("Ingrese un número real: "))

raiz = math.sqrt(num)

print("La raíz cuadrada de", num, "es:", raiz)
